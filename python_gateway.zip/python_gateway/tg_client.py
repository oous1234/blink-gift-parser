import logging
from telethon import TelegramClient, connection
from config import settings

logger = logging.getLogger(__name__)

class TelegramSession:
    def __init__(self):
        client_kwargs = {
            'session': settings.SESSION_NAME,
            'api_id': settings.API_ID,
            'api_hash': settings.API_HASH
        }

        if settings.USE_PROXY:
            logger.info(f"Using MTProto proxy: {settings.PROXY_HOST}")
            client_kwargs['connection'] = connection.ConnectionTcpMTProxyRandomizedIntermediate
            client_kwargs['proxy'] = (settings.PROXY_HOST, settings.PROXY_PORT, settings.PROXY_SECRET)

        self.client = TelegramClient(**client_kwargs)

    async def connect(self):
        await self.client.connect()
        if not await self.client.is_user_authorized():
            logger.error("Session not authorized. Run manual auth script first.")
            raise RuntimeError("Telegram authorization required")
        logger.info("Telegram client connected and authorized.")

    async def disconnect(self):
        await self.client.disconnect()

tg_session = TelegramSession()